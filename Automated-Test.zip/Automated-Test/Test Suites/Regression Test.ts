<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Regression Test</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>1d4bd90a-47b3-49e6-9ec7-222a94f58bd7</testSuiteGuid>
   <testCaseLink>
      <guid>82188f5a-e16c-44cd-96ca-37d53378531a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC001 - Sign In (Unregistered)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a7567a07-4d52-4fe8-b47b-d404cb174b39</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC002 - Sign In (Empty Email)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1475f6ee-7bae-4e4a-b75f-af7824b33332</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC003 - Sign In (Empty Password)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e7bb7cc1-096f-45b9-9a35-29e3e8914e5d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC004 - Sign In (Invalid Email)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>52ab4e79-7ce5-48ed-ac09-d665a8a12f30</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC005 - Sign Up (Invalid Email)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fcd8f25d-0860-4dac-81e1-46b25d92b133</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC006 - Sign Up (Empty Email)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b446c8d8-34a0-4c98-802e-d73f2b4abc08</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC007 - Sign Up (Valid Email)</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
